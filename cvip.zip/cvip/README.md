# CVIP-LandingPageForEdTech (Normal Task)
This repository contains a project completed during Web Development Internship Phase-1 under CodersCave Virtual Internship Program(CVIP) August 2023. This project is a Normal Task of phase-1 which is a Landing Page for Education Technology, created using HTML, CSS & JavaScript. 
